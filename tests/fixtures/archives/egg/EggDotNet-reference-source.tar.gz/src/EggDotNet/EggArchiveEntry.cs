﻿using EggDotNet.Format;
using EggDotNet.SpecialStreams;
using System;
using System.IO;

namespace EggDotNet
{
	/// <summary>
	/// Represents an entry with an EGG archive.
	/// </summary>
	public sealed class EggArchiveEntry
	{
		private EggFileFormatBase format => Archive.format;

		internal readonly EggFileEntryBase entry;
		internal long PositionInStream => entry.Position;
		
		/// <summary>
		/// Gets the parent <see cref="EggArchive"/> for this entry.
		/// </summary>
		public EggArchive Archive { get; private set; }

		/// <summary>
		/// Gets the ID of the egg entry.
		/// </summary>
		public int Id => entry.Id;

		/// <summary>
		/// Gets the name of the egg entry, not including any directory.
		/// </summary>
#if NULLABLE
		public string? Name => Path.GetFileName(FullName);
#else
		public string Name => Path.GetFileName(FullName);
#endif

		/// <summary>
		/// Gets the name of the egg entry, including any directory.
		/// </summary>
#if NULLABLE
		public string? FullName => entry.Name;
#else
		public string FullName => entry.Name;
#endif

		/// <summary>
		/// Gets the Crc32 checksum for this entry.
		/// </summary>
		public uint Crc32 => entry.Crc32;

		/// <summary>
		/// Gets a flag indicating whether the entry is encrypted.
		/// </summary>
		public bool IsEncrypted => entry.IsEncrypted;

		/// <summary>
		/// Gets the compressed length of the file.
		/// </summary>
		public long CompressedLength => entry.CompressedSize;

		/// <summary>
		/// Gets the uncompressed length of the file.
		/// </summary>
		public long UncompressedLength => entry.UncompressedSize;

		/// <summary>
		/// Gets the compression method used to compress this entry.
		/// </summary>
		public CompressionMethod CompressionMethod => entry.CompressionMethod;

#if NULLABLE
		/// <summary>
		/// Gets the last write time of the file.
		/// </summary>
		/// <remarks>
		/// If no mod date is present, value will be null.
		/// </remarks>
		public DateTime? LastWriteTime => entry.LastWriteTime;
#else
		/// <summary>
		/// Gets the last write time of the file.
		/// </summary>
		/// <remarks>
		/// If no mod date is present, value will be default value (min value).
		/// </remarks>
		public DateTime LastWriteTime => entry.LastWriteTime;
#endif

		/// <summary>
		/// Gets the comment of the file.
		/// </summary>
		public string Comment => entry.Comment ?? string.Empty;

		/// <summary>
		/// Gets the EntryInfoType value for this EggArchiveEntry.
		/// </summary>
		public EntryInfoType EntryInfoType => entry.EntryInfoType;

		internal EggArchiveEntry(EggFileEntryBase entry, EggArchive archive)
		{
			Archive = archive;
			this.entry = entry;
		}

		/// <summary>
		/// Produces a stream to the entry.
		/// </summary>
		/// <returns>A Stream to the entry.</returns>
		public Stream Open()
		{
			return format.GetStreamForEntry(this);
		}

		/// <summary>
		/// Gets extra attributes associated with the Entry.
		/// </summary>
		/// <param name="attributeType"></param>
		/// <returns></returns>
		public long GetExtraAttributes(ExtraAttributeType attributeType)
		{
			return entry.GetExtraAttributes(attributeType);
		}

		/// <summary>
		/// Verifies the checksum.
		/// </summary>
		/// <returns>True is checksum matches, false if not.</returns>
		public bool ChecksumValid()
		{
			using (var st = format.GetStreamForEntry(this))
			{
				using (var crc = new Crc32Stream(st))
				{
					var data = new byte[8192];
					while (crc.Read(data, 0, data.Length) > 0) { };
					return crc.Crc == Crc32;
				}
			}
		}

		/// <inheritdoc/>
		public override string ToString()
		{
			if (string.IsNullOrWhiteSpace(entry.Name))
			{
				return $"{nameof(EggArchiveEntry)} {entry.Id}";
			}
			return $"{nameof(EggArchiveEntry)} {entry.Id} - {entry.Name}";
		}
	}
}
