﻿using EggDotNet.Encryption.Lea;
using System.IO;
using System.Security.Cryptography;

namespace EggDotNet.Encryption
{
	internal sealed class LeaStreamDecryptionProvider : IStreamDecryptionProvider
	{
		private readonly byte[] _footer;
		private readonly int _bits;
		private readonly byte[] _header;
		private ICryptoTransform _cryptoTransform;
		private byte[] _macIv;

		public LeaStreamDecryptionProvider(int bits, byte[] header, byte[] footer)
		{
			_footer = footer;
			_bits = bits;
			_header = header;
		}

		public bool AttachAndValidatePassword(string password)
		{
			using (var lea = new Lea.Imp.Lea(_bits, password, _header))
			{
				if (lea.PasswordValid)
				{
					_cryptoTransform = lea.CreateDecryptor(lea.Key, new byte[16]);
					_macIv = (byte[])lea.MacKey.Clone();
					return true;
				}
				return false;
			}
		}

		public Stream GetDecryptionStream(Stream stream)
		{
			return new LeaStream(stream, _cryptoTransform, _macIv, _footer);
		}
	}
}
