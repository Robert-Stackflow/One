﻿using System;

namespace EggDotNet.Format
{
	internal abstract class EggFileEntryBase
	{
		public abstract int Id { get; }

		public abstract string Name { get; }

		public abstract uint Crc32 { get; }

		public abstract bool IsEncrypted { get; }

		public abstract long UncompressedSize { get; }

		public abstract long CompressedSize { get;  }

		public abstract CompressionMethod CompressionMethod { get; }

		public abstract long Position { get; }

#if NULLABLE
		public abstract DateTime? LastWriteTime { get; }

		public abstract string? Comment { get; }
#else
		public abstract DateTime LastWriteTime { get; }

		public abstract string Comment { get; }
#endif

		public abstract EntryInfoType EntryInfoType { get; }

		public abstract long GetExtraAttributes(ExtraAttributeType attributeType);
	}
}
