﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using EggDotNet.InternalExtensions;

#if !USE_SPAN
using BitConverter = EggDotNet.InternalExtensions.BitConverterWrapper;
#endif

namespace EggDotNet.Format.Egg
{
    internal sealed class EggEntry : EggFileEntryBase
	{
		public FileHeader FileHeader { get; private set; }

		public FilenameHeader FilenameHeader { get; private set; }

		public PosixFileInfo PosixFileInfo { get; private set; }

		public WinFileInfo WinFileInfo { get; private set; }

		public EncryptHeader EncryptHeader { get; private set; }

		public BlockHeader BlockHeader { get; private set; }

		public CommentHeader CommentHeader { get; private set; }

		public override int Id => FileHeader.FileId;

		public override string Name => FilenameHeader.FileNameFull;

		public override long Position => BlockHeader.BlockDataPosition;

		public override long UncompressedSize => FileHeader.FileLength;

		public override long CompressedSize => BlockHeader.CompressedSize;

		public override CompressionMethod CompressionMethod => BlockHeader.CompressionMethod;

		public override uint Crc32 => BlockHeader.Crc32;

		public override bool IsEncrypted => EncryptHeader != null;

#if NULLABLE
		public override DateTime? LastWriteTime => GetLastWriteTime();

		public override string? Comment => CommentHeader.CommentText;
#else
		public override DateTime LastWriteTime => GetLastWriteTime();

		public override string Comment => CommentHeader.CommentText;
#endif

		public override EntryInfoType EntryInfoType => GetEntryInfoType();

		public static List<EggEntry> ParseEntries(Stream stream, EggArchive archive)
		{
			if (archive.format is EggFormat eggFormat && eggFormat.IsSolid)
			{
				return ParseSolidEntries(stream, archive);
			}
			else
			{
				return ParseIndividualEntries(stream, archive);
			}
		}

		public override long GetExtraAttributes(ExtraAttributeType attributeType)
		{
			if (attributeType == ExtraAttributeType.FileAttibutes)
			{
				return GetFileAttributes();
			}
			else if (attributeType == ExtraAttributeType.UserGroupAttributes)
			{
				return GetUserGroupAttributes();
			}
			else if (attributeType == ExtraAttributeType.DateAttributes)
			{
				return GetLastWriteTimeRaw();
			}

			return 0;
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private static List<EggEntry> ParseSolidEntries(Stream stream, EggArchive archive)
		{
			var entries = new List<EggEntry>();
			while (true)
			{
				var entry = new EggEntry();
				BuildHeaders(entry, archive, stream, out var foundData);

				if (foundData || stream.Position >= stream.Length) break; //sanity check

				entries.Add(entry);
			}

			var headerEntry = entries.First();
			BuildBlocks(headerEntry, stream);
			foreach (var otherEntry in entries.Skip(1))
			{
				otherEntry.BlockHeader = BlockHeader.CloneEmpty(headerEntry.BlockHeader);
			}

			return entries;
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private static List<EggEntry> ParseIndividualEntries(Stream stream, EggArchive archive)
		{
			var entries = new List<EggEntry>();
			while (true)
			{
				var entry = new EggEntry();

				BuildHeaders(entry, archive, stream, out _);

				if (stream.Position >= stream.Length) break; //sanity check

				if (entry.UncompressedSize > 0) //check for empty entries (e.g. directories)
				{
					BuildBlocks(entry, stream);
				}

				entries.Add(entry);
			}

			return entries;
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private static void BuildHeaders(EggEntry entry, EggArchive archive, Stream stream, out bool foundData)
		{
			foundData = false;
			var foundEnd = false;
			var insideFileheader = false;
#if USE_SPAN
			Span<byte> buff = stackalloc byte[4];
#else
			var buff = new byte[4];
#endif
			while (!foundEnd && stream.Read(buff) == 4)
			{
				var nextHeader = BitConverter.ToInt32(buff);

				switch (nextHeader)
				{
					case FileHeader.FILE_HEADER_MAGIC:
						entry.FileHeader = FileHeader.Parse(stream);
						insideFileheader = true;
						break;
					case FilenameHeader.FILENAME_HEADER_MAGIC:
						entry.FilenameHeader = FilenameHeader.Parse(stream);
						break;
					case WinFileInfo.WIN_FILE_INFO_MAGIC_HEADER:
						entry.WinFileInfo = WinFileInfo.Parse(stream);
						break;
					case PosixFileInfo.POSIX_FILE_INFO_MAGIC_HEADER:
						entry.PosixFileInfo = PosixFileInfo.Parse(stream);
						break;
					case EncryptHeader.EGG_ENCRYPT_HEADER_MAGIC:
						entry.EncryptHeader = EncryptHeader.Parse(stream);
						break;
					case CommentHeader.COMMENT_HEADER_MAGIC:
						var comment = CommentHeader.Parse(stream);
						if (insideFileheader)
							entry.CommentHeader = comment;
						else
							archive.Comment = comment.CommentText;
						break;
					case DummyHeader.DUMMY_HEADER_MAGIC:
						_ = DummyHeader.Parse(stream);
						break;
					case FileHeader.FILE_END_HEADER:
						foundEnd = true;
						break;
					case BlockHeader.BLOCK_HEADER_MAGIC:
						foundEnd = true;
						foundData = true;
						stream.Seek(-4, SeekOrigin.Current);
						break;
					default:
						foundEnd = true;
						break;
				}
			}
		}

		//It may be incorrect to assume that an entry is contained in only one block per volume.  This method won't work if so because
		//it applies one block per entry.  It should be relatively easy to revise if needed (although it will complicate block retrieval).
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private static void BuildBlocks(EggEntry entry, Stream stream)
		{
#if USE_SPAN
			Span<byte> buffer = stackalloc byte[4];
#else
			var buffer = new byte[4];
#endif
			while (stream.Read(buffer) == 4)
			{
				if (BitConverter.ToInt32(buffer) == BlockHeader.BLOCK_HEADER_MAGIC)
				{
					entry.BlockHeader = BlockHeader.Parse(stream);
					stream.Seek(entry.CompressedSize, SeekOrigin.Current);
					break;
				}
			}
		}

#if NULLABLE
		private DateTime? GetLastWriteTime()
		{
			if (WinFileInfo != null)
			{
				return DateUtilities.FromEggTime(GetLastWriteTimeRaw());
			}
			else if (PosixFileInfo != null)
			{
				return DateUtilities.FromEpoch(GetLastWriteTimeRaw());
			}

			return null;
		}

#else
		private DateTime GetLastWriteTime()
		{
			if (WinFileInfo != null)
			{
				return DateUtilities.FromEggTime(GetLastWriteTimeRaw());
			}
			else if (PosixFileInfo != null)
			{
				return DateUtilities.FromEpoch(GetLastWriteTimeRaw());
			}

			return DateTime.MinValue;
		}
#endif

		private long GetLastWriteTimeRaw()
		{
			if (WinFileInfo != null)
			{
				return WinFileInfo.LastModified;
			}
			else if (PosixFileInfo != null)
			{
				return PosixFileInfo.LastModified;
			}

			return 0;
		}

		private long GetFileAttributes()
		{
			if (WinFileInfo != null)
			{
				return WinFileInfo.WindowsFileAttributes;
			}
			else if(PosixFileInfo != null)
			{
				return PosixFileInfo.FileMode;
			}
			else
			{
				return 0;
			}
		}

		private long GetUserGroupAttributes()
		{
			if (WinFileInfo != null)
			{
				return 0;
			}
			else if (PosixFileInfo != null)
			{
				return ((long)PosixFileInfo.Uid << 32) | (long)(uint)PosixFileInfo.Gid;
			}

			return 0;
		}

		private EntryInfoType GetEntryInfoType()
		{
			if (WinFileInfo != null)
			{
				return EntryInfoType.Windows;
			}
			else if (PosixFileInfo != null)
			{
				return EntryInfoType.Posix;
			}
			return EntryInfoType.None;
		}
	}
}
