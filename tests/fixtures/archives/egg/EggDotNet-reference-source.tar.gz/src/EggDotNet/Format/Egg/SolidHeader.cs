﻿using System.IO;

#if USE_SPAN
using System;
#else
using EggDotNet.InternalExtensions;
#endif

namespace EggDotNet.Format.Egg
{
    internal sealed class SolidHeader
	{
		public const int SOLID_HEADER_MAGIC = 0x24E5A060;

		public static SolidHeader Parse(Stream stream)
		{
#if USE_SPAN
			Span<byte> buffer = stackalloc byte[3];
#else
			var buffer = new byte[3];
#endif
			if (stream.Read(buffer) != 3)
			{
				throw new InvalidDataException("Failed reading solid header");
			}

			return new SolidHeader();
		}
	}
}
